<div class="modal fade" id="showJobcard" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">New message</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <h6>Card Number : <span class="card-number"></span></h6>
          <h6>Date Opened : <span class="date-opened"></span></h6>
          <h6>Month : <span class="month"></span></h6>
          <h6>Quantity : <span class="quantity"></span></h6>
          <h6>Issued : <span class="issued"></span></h6>
          <h6>Job Card Type : <span style="text-transform: capitalize" class="cardtype"></span></h6>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-success btn-sm" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
